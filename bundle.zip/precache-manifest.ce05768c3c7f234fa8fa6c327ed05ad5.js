self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "0529369ec6ff08dfb388083fae58438d",
    "url": "./index.html"
  },
  {
    "revision": "1bbaa99ef9069e01f91e",
    "url": "./static/css/2.4fc5a6bc.chunk.css"
  },
  {
    "revision": "1bbaa99ef9069e01f91e",
    "url": "./static/js/2.5573b2e7.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "./static/js/2.5573b2e7.chunk.js.LICENSE.txt"
  },
  {
    "revision": "8f1d937a2975c1d46bd4",
    "url": "./static/js/main.f229f2de.chunk.js"
  },
  {
    "revision": "bc324f8dde2cb1a4be5e",
    "url": "./static/js/runtime-main.bf459c70.js"
  }
]);